package com.cognizant.tweetapp.utility;

public class Constants {

	public final static String url= "jdbc:mysql://localhost:3306/tweetdb";
	
	public	final static String username="root";
	
	public final static String password="root123";
	
	
			
}
