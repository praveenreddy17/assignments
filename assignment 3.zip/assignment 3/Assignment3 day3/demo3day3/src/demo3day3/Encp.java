package demo3day3;

public class Encp {

	public static void main(String[] args) {
		Encapsulation ee=new Encapsulation();
		ee.setId(1);
		ee.getId();

	}

}
